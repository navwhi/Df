# STF (DeviceFarmer) — notes de la conversation du 20 octobre 2026

Contenu du zip :

- `conversation.md` : ce fichier (questions et réponses)
- `patches/stf-api-port-forward.patch` : ajout du port forwarding à l'API REST
- `patches/stf-provider-restart-killed-workers.patch` : relance des device workers tués par un signal (OOM…)

Les deux patchs sont indépendants. Pour les appliquer, à la racine du dépôt STF :

```bash
git apply patches/stf-api-port-forward.patch
git apply patches/stf-provider-restart-killed-workers.patch
```

---

## 1. Gérer le port forwarding via l'API

> **Question :** Quand je branche un téléphone, je peux interagir avec lui sur l'interface graphique, et notamment gérer le forward de port. J'aimerais pouvoir le faire avec l'API. Où est gérée la page web, et comment ajouter cette interaction ?

### Comment le port forwarding fonctionne aujourd'hui

L'interface ne fait pas d'appel HTTP pour le forward : tout passe par le **websocket**, puis par ZeroMQ jusqu'au processus qui pilote le téléphone.

1. **Front-end** (`res/app/src/…`)
   - `features/control/panes/advanced/portForwardsStore.ts` : l'onglet *Advanced → Port forwarding* de la page de contrôle.
   - `core/control.ts` : il émet `forward.create`, `forward.remove` et `forward.test` sur le websocket.
2. **Unité websocket** (`lib/units/websocket/index.ts`, vers la ligne 1043) : elle transforme ces événements en messages protobuf `wire.ForwardCreateMessage` et `ForwardRemoveMessage`, puis les pousse sur le canal du device. Si `targetHost` vaut `localhost` ou est vide, elle le remplace par l'IP de l'utilisateur.
3. **Plugin device** (`lib/units/device/plugins/forward/index.ts`) : il lance `minirev` sur le téléphone, crée le tunnel et répond par un `TransactionDoneMessage` (succès ou échec). Il publie aussi un `ReverseForwardsEvent`. Le processor l'enregistre ensuite en base dans `device.reverseForwards` (`lib/db/api.ts`).

**L'API REST** se trouve dans `lib/units/api/` :

- `swagger/api_v1.yaml` déclare les routes. Chaque `operationId` correspond à une fonction exportée par le contrôleur indiqué dans `x-swagger-router-controller`.
- `controllers/user.ts` contient les actions sur les devices que tu contrôles. `remoteConnectUserDeviceBySerial` y suit déjà le schéma dont on a besoin : envoyer un message au device dans une transaction ZeroMQ, puis attendre sa réponse.

### Ce que le patch `stf-api-port-forward.patch` ajoute

| Méthode | Route | Rôle |
|---|---|---|
| `GET` | `/api/v1/user/devices/{serial}/forwards` | liste les forwards actifs (lus dans `device.reverseForwards`) |
| `POST` | `/api/v1/user/devices/{serial}/forwards` | crée un forward |
| `DELETE` | `/api/v1/user/devices/{serial}/forwards/{id}` | supprime un forward |

Fichiers modifiés :

- **`lib/units/api/controllers/user.ts`** : ajout d'un helper `sendForwardTransaction`. Il s'abonne à un canal `txn_<uuid>`, envoie le message au device et attend le `TransactionDoneMessage`. La réponse est un 201 en cas de succès, un 500 si le device renvoie `fail_forward`, et un 504 au bout de 10 s sans réponse.
- **`lib/units/api/swagger/api_v1.yaml`** : déclaration des routes et du corps de requête.
- **`lib/types/units-api.d.ts`** : typage du paramètre `forward`.

Le device doit être pris en main au préalable, comme pour les autres routes `/user/devices` : soit via `POST /api/v1/user/devices` avec le serial, soit depuis l'interface.

```bash
TOKEN=xxx; STF=http://localhost:7100

# prendre le device
curl -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"serial":"EMULATOR123"}' $STF/api/v1/user/devices

# forward : port 8080 du téléphone -> 192.168.1.20:3000
curl -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"devicePort":8080,"targetHost":"192.168.1.20","targetPort":3000}' \
  $STF/api/v1/user/devices/EMULATOR123/forwards

# lister / supprimer
curl -H "Authorization: Bearer $TOKEN" $STF/api/v1/user/devices/EMULATOR123/forwards
curl -X DELETE -H "Authorization: Bearer $TOKEN" $STF/api/v1/user/devices/EMULATOR123/forwards/<id>
```

### Points à connaître

- **`targetHost` est à préciser.** C'est le *provider* qui ouvre la connexion vers la cible, pas ton poste. Si tu omets `targetHost` ou si tu mets `localhost`, l'IP de l'appelant (`req.ip`) est utilisée, comme dans l'interface. Derrière un reverse proxy, ce sera l'IP du proxy, donc mieux vaut indiquer l'hôte explicitement.
- **Les forwards sont supprimés quand tu libères le device** (`group.on('leave', plugin.reset)`), comme dans l'UI.
- **Vérification.** Le YAML est valide. Le type-check ne signale aucune erreur nouvelle, hormis des `message is of type unknown` dans les handlers `wirerouter`, identiques à ceux du code existant (les types protobuf sont générés au build). Le patch n'a pas été testé avec un vrai téléphone. Après application, relance `stf local` (ou l'unité `api`). Les routes apparaissent dans le Swagger UI sur `/api/v1/docs`.

---

## 2. Téléphones inaccessibles (écran gris) jusqu'à un `docker compose down/up`

> **Question :** Pourquoi les téléphones du provider deviennent-ils parfois inaccessibles (écran gris sur l'interface web), sans aucune interaction possible ? Je suis obligé de faire `docker compose down` puis `docker compose up -d` pour que ça refonctionne.

### Ce que signifie l'écran gris

Chaque téléphone est géré par un **device worker**, un processus fils du provider. Ce worker diffuse l'écran (via minicap) sur son propre websocket, dans la plage 7400-7500. Le navigateur s'y connecte directement, à l'adresse `ws://STF_PUBLIC_IP:<port>`. L'écran gris veut dire que ce websocket ne livre aucune image. Les clics, eux, passent par ZeroMQ (websocket → triproxy → provider → worker). Quand rien ne répond non plus, c'est en général toute la chaîne qui est bloquée.

### Causes probables, vues dans le code

1. **Le worker est tué par un signal et n'est jamais relancé** (suspect principal). Dans `lib/units/provider/index.ts`, si un worker meurt avec un code d'erreur, il est relancé après 500 ms. S'il meurt à cause d'un **signal**, il est abandonné (« assuming deliberate action and not restarting »). C'est le cas d'un **SIGKILL envoyé par l'OOM killer** quand la mémoire manque.
2. **minicap est bloqué sans être tombé.** Dans `lib/units/device/plugins/screen/stream.ts`, le flux ne réagit qu'à la fin du socket minicap (`_socketEnded`) ou du shell (`_outputEnded`). Si minicap reste vivant mais n'envoie plus d'images (veille profonde, verrouillage, rotation sur certains modèles), rien ne le détecte.
3. **Le serveur adb est bloqué.** Le conteneur `adb` partage `/dev/bus/usb`. Après une ré-énumération USB (câble, hub, veille de l'hôte), le serveur adb peut garder des devices `offline` ou ne plus répondre aux commandes.
4. **Un seul conteneur a redémarré** (`restart: unless-stopped`), par exemple `triproxy-dev`, `adb` ou `provider`. Les autres gardent des connexions vers l'ancienne instance. Un `down/up` remet tout d'aplomb.

### Diagnostic, la prochaine fois que ça arrive

```bash
# Le worker a-t-il été tué ou bloqué ?
docker compose logs --since 2h provider | grep -E "killed with signal|died with code|Too many|minicap|Frame producer|not restarting"

# OOM killer ?
docker compose ps -a          # un conteneur avec "Restarting" ou un uptime plus court que les autres ?
dmesg -T | grep -i -E "oom|killed process"

# adb voit-il encore les téléphones ?
docker compose exec adb adb devices -l

# Les processus device tournent-ils ?
docker compose exec provider ps aux | grep "device --serial"
```

Essaie ensuite de redémarrer un seul composant, pour isoler celui qui est bloqué :

- `docker compose restart adb provider` : si ça suffit, le problème vient du côté adb/USB ou des workers (causes 1 à 3).
- Si seul un `down/up` complet répare, regarde quel conteneur a un uptime différent des autres (cause 4).

### Pistes de correctifs selon le diagnostic

- **Cause 1** : donner plus de mémoire au provider, et faire relancer les workers tués par un signal non demandé par STF (voir le patch, section 3).
- **Cause 2** : ajouter un watchdog dans `FrameProducer` qui appelle `failCounter.inc()` et `restart()` si aucune frame n'arrive pendant X secondes alors qu'un client regarde. On peut aussi désactiver la veille sur les téléphones (option développeur « Rester éveillé »).
- **Cause 3** : vérifier le câblage et les hubs USB, et désactiver l'autosuspend USB sur l'hôte (`usbcore.autosuspend=-1`).

---

## 3. Mémoire des conteneurs, et détail du correctif de la cause 1

> **Question :** Comment voir la mémoire utilisée par un conteneur, et comment la modifier ? Et peux-tu développer le correctif de la cause 1 ?

### Voir la mémoire

```bash
# En direct pour tous les conteneurs du compose (colonne MEM USAGE / LIMIT)
docker stats $(docker compose ps -q)

# Instantané, sans rafraîchissement
docker stats --no-stream

# Limite configurée (0 = pas de limite)
docker inspect -f '{{.HostConfig.Memory}}' $(docker compose ps -q provider)

# Le conteneur a-t-il été tué par l'OOM killer ?
docker inspect -f '{{.State.OOMKilled}}' $(docker compose ps -q provider)
```

`OOMKilled` ne passe à `true` que si le **processus principal** du conteneur est tué. Si c'est un device worker (processus fils) qui est visé, il reste à `false`. Il faut alors regarder dans `dmesg -T | grep -i oom` sur l'hôte : une ligne `Killed process … (node)` apparaît.

Dans `docker stats`, si la limite affichée est égale à la RAM totale de la machine, aucune limite n'est posée. Le risque vient alors de la RAM de l'hôte, pas de Docker.

### Modifier la limite

Dans `docker-compose.yaml`, sous le service concerné :

```yaml
  provider:
    <<: *stf
    command: >-
      stf provider ...
    mem_limit: 3g          # plafond dur
    mem_reservation: 1g    # optionnel : réservation souple
```

La syntaxe `deploy: resources: limits: memory: 3g` fonctionne aussi avec Compose v2. Applique ensuite avec `docker compose up -d provider`, qui recrée uniquement ce conteneur.

Ordre de grandeur : un device worker consomme en général entre 100 et 250 Mo, davantage pendant l'installation d'un APK ou quand l'écran est streamé en haute résolution. Avec 5 téléphones, 2 à 3 Go pour le provider laissent une bonne marge.

### Le correctif `stf-provider-restart-killed-workers.patch`

**Le problème.** Le provider surveille chaque worker via `exitListener` (`lib/units/provider/index.ts`). Quand un processus se termine, Node fournit soit un **code de sortie**, soit le **signal** qui l'a tué. Le code d'origine traite ces cas ainsi :

- code ≠ 0 : le worker a planté, on le relance ;
- code = 0 : arrêt propre, on le laisse ;
- **signal quelconque** : on suppose que STF l'a arrêté volontairement, et on ne relance pas.

Cette supposition est fausse. STF arrête bien ses workers par signal, via `gracefullyKill` qui envoie SIGTERM puis SIGKILL. Mais l'OOM killer, un `kill` manuel ou un crash natif (SIGSEGV) arrivent eux aussi sous forme de signal. Le worker est alors classé comme « retraité », le provider envoie `DeviceAbsentMessage`, et le téléphone reste mort jusqu'au redémarrage du provider.

**Le correctif** consiste à retenir si c'est STF qui a demandé l'arrêt :

1. Une variable `stopRequested`, propre à chaque worker, passe à `true` dans `promise.stop()`. C'est le seul chemin par lequel STF tue volontairement un worker (téléphone débranché, passage en `offline`/`unauthorized`, arrêt du provider).
2. Dans `exitListener` :
   - si le worker est tué par un signal **et** que `stopRequested` ou `lifecycle.ending` (le provider est en train de s'arrêter) est vrai, c'est un arrêt voulu et on ne fait rien de plus ;
   - si le worker est tué par un signal **sans** demande de STF, on rejette avec un `ExitError` de code `128 + n° du signal` (137 pour SIGKILL). La logique existante de `work()` intercepte déjà `ExitError` : elle écrit `died with code 137`, attend 500 ms et relance le worker sur de nouveaux ports.

Ce qui ne change pas : un téléphone réellement débranché n'est pas relancé (`willStop` reste vérifié dans `work()`), et un `docker compose stop` arrête proprement tous les workers grâce à `lifecycle.ending`.

**Une limite à connaître.** Si la mémoire manque en permanence, le worker relancé sera tué à nouveau, d'où une boucle de redémarrages toutes les quelques secondes. Au moins, ça se voit dans les logs (`killed unexpectedly with signal SIGKILL (OOM killer?)`), mais le vrai remède reste d'augmenter la mémoire. Le type-check ne signale aucune erreur nouvelle.

**Pour tester** sans attendre un OOM, tue un worker à la main :

```bash
docker compose exec provider pkill -9 -f "device --serial <SERIAL>"
```

Le téléphone doit revenir de lui-même en quelques secondes.
